<!DOCTYPE html>
<html>
    <head>
        <title>
            
        </title>
    </head>
    <body>
        <form action="include/signup.inc.php" method="POST">
            <input type="text" name="first" placeholder="firstname"><br/>
            <input type="text" name="last" placeholder="lasttname"><br/>
            <input type="text" name="email" placeholder="E-mail"><br/>
            <input type="text" name="uid" placeholder="Username"><br/>
            <input type="password" name="pwd" placeholder="password"><br/>
            <button type="submit" name="submit"> Sign up</button>
        </form>
        <a href="signup.php">Sing up</a>
    </body>
</html>