<?php
include_once 'header.php';
    if(isset($_SESSION['u_id'])){
        echo $_SESSION['u_id'];
    }
?>


