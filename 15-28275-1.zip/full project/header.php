<!DOCTYPE html>
<html>
    <head>
        <title>
            
        </title>
    </head>
    <body>
        <form action="include/login.inc.php" method="POST">
            <input type="text" name="uid">
            <input type="password" name="pwd">
            <button type="submit" name="submit"> Login</button>
        </form>
        <a href="signup.php">Sing up</a>
    </body>
</html>