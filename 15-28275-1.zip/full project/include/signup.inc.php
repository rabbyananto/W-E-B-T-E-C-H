<?php
    if(isset($_POST['submit'])){
        include_once 'dbh.inc.php';
        $name = mysqli_real_escape_string($conn, $_POST['name']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $uid = mysqli_real_escape_string($conn, $_POST['userName']);
        $pwd = mysqli_real_escape_string($conn, $_POST['password']);
        $gender = mysqli_real_escape_string($conn, $_POST['password']);
        
        if(empty($name) || empty($email) || empty($uid) || empty($pwd)){
           
            header("Location: ../registration.php?registration=empty");
            exit();
        }
        else{
                    $sql = "SELECT * FROM users WHERE username='$uid'";
                    $result = mysqli_query($conn, $sql);
                    $resultCheck = mysqli_num_rows($result);
                    if($resultCheck > 0){
                        header("Location: ../registration.php?signup=usertaken");
                        exit();
                    }
                    else{
                        
                        $sql = "INSERT INTO users (name,email, username, password,gender) VALUES ('$name','$email','$uid','$pwd',$gender);";
                        mysqli_query($conn,$sql);
                        header("Location: ../registration.php?signup=success");
                        exit();
                    }
                
            
        }
    }
else{
    header("Location: ../registration.php");
    exit();
}
?>